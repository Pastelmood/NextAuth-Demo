import NextAuth, { DefaultSession, User } from "next-auth";
import Credentials from "next-auth/providers/credentials";

export const { handlers, signIn, signOut, auth } = NextAuth({
  providers: [
    Credentials({
      authorize(credentials) {
        const user = {
          email: credentials?.email as string,
          name: credentials?.name as string,
          image: credentials?.image as string,
          role: credentials?.role as string,
          userId: credentials?.userId as string,
        };

        return user;
      },
    }),
  ],
});
